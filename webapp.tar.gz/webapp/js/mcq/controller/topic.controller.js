/**
 * 主题管理的Controller
 * @type {angular.Module}
 * @author zhufei, zhuchunlai
 */
angular.module('mcqControllers')
    // 查询
    .controller('topicQueryCtrl', function ($scope, topicService) {
        /**
         * 搜索主题
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有用户
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            topicService.search(aQuery, pagination).success(function (data) {
                if (pageNo) {
                    $scope.paginationConf.pageNo = pageNo;
                }
                $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                $scope.topics = data.result;
                $scope.loading = false;
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

    // 加载编辑页面
    .controller('topicEditModalCtrl', function ($scope, $uibModal) {

        $scope.toEditModal = function (topicId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/topic/edit.tpl.html',
                controller: 'topicEditCtrl',
                scope: $scope,
                resolve: {
                    topicId: topicId
                }
            });
        };
    })

    // 编辑
    .controller('topicEditCtrl', function ($scope, $timeout, $uibModalInstance, topicService, topicId) {
        /**
         * 按ID查询主题明细
         * @param id 主题ID
         */
        $scope.findById = function (id) {
            topicService.findById(id).success(function (data) {
                if (data.status == 200) {
                    $scope.topic = data.result;

                    $scope.operation = null;
                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败'
                    };
                }
            });
        };

        /**
         * 编辑主题信息
         * @param topic 主题
         */
        $scope.ok = function (topic) {
            $scope.confirmDisabled = true;
            topicService.update(topic).success(function (data) {
                if (data.status == 200) {
                    $scope.operation = {
                        "success": true,
                        "message": "编辑成功"
                    };
                    $timeout(function () {
                        $scope.cancel();
                        $scope.search();
                    }, 1000);
                } else {
                    $scope.operation = {
                        "success": false,
                        "message": data.message
                    }
                }


            });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.findById(topicId);
    })

    //加载删除页面
    .controller('topicDeleteModalCtrl', function ($scope, $uibModal) {
        $scope.toDeleteModal = function (topicId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/topic/delete.tpl.html',
                controller: 'topicDeleteCtrl',
                scope: $scope,
                resolve: {
                    topicId: topicId
                }
            });
        }
    })

    //删除Topic
    .controller('topicDeleteCtrl', function ($scope, $uibModalInstance, $timeout, topicService, topicId) {
        /**
         * 删除指定Topic信息
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;
            topicService.delete(topicId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        }

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })
;
