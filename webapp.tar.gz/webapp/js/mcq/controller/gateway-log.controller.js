angular.module('mcqControllers')

// 列表
    .controller('gatewayLogQueryCtrl', function ($scope, $filter, gatewayLogService) {
        /**
         * 搜索应用
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有日志
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };

            var aQuery = query ? query : $scope.query;
            // 拷贝数据,避免后续的修改影响scope中的数据
            aQuery = angular.copy(aQuery);

            if (aQuery) {
                if (aQuery.startReqTime) {
                    aQuery.startReqTime = $filter('date')(aQuery.startReqTime, 'yyyy-MM-dd');
                }
                if (aQuery.endReqTime) {
                    aQuery.endReqTime = $filter('date')(aQuery.endReqTime, 'yyyy-MM-dd');
                }
            }

            gatewayLogService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.gatewayLogs = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

    .controller('gatewayLogDetailModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载明细页面
         * @param gatewayLog 网关日志
         */
        $scope.toDetailModal = function (gatewayLog, options) {

            var aOptions = {reqModal: false, respModal: false};
            angular.extend(aOptions, options);

            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/gateway_log/detail.tpl.html',
                controller: 'gatewayLogDetailCtrl',
                scope: $scope,
                resolve: {
                    gatewayLog: gatewayLog,
                    options: aOptions
                }
            });
        };
    })

    // 明细页面
    .controller('gatewayLogDetailCtrl', function ($scope, $uibModalInstance, gatewayLog, options) {

        var title, detail;
        if (options.reqModal) {
            title = '请求报文';
            detail = gatewayLog.reqContent;
        } else {
            title = '应答报文';
            detail = gatewayLog.respContent;
        }

        $scope.title = title;
        $scope.detail = JSON.stringify(JSON.parse(detail), undefined, 2);

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

;