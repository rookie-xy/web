/**
 * Topic与app关系管理的Controller
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqControllers')
    // 加载订阅关系页面
    .controller('topicSubscribeModalCtrl', function ($scope, $uibModal) {

        $scope.toSubscribeModal = function (topicId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/topic/subscribe.tpl.html',
                controller: 'topicSubscribeCtrl',
                scope: $scope,
                resolve: {
                    topicId: topicId
                }
            });
        };
    })

    // 订阅关系
    .controller('topicSubscribeCtrl', function ($scope, $uibModalInstance, $timeout, appTopicService, topicId) {
        /**
         * 查询指定Topic的订阅关系
         * @param topicId topic标识
         */
        $scope.findApp = function (topicId) {
            appTopicService.findByTopic(topicId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.appTopics = data.result;

                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败'
                    };
                });
        };

        /**
         * 删除应用/Topic订阅关系
         * @param selectedAppTopics 订阅关系标识
         */
        $scope.batchDelete = function (selectedAppTopics) {
            $scope.confirmDisabled = true;
            appTopicService.batchDelete(selectedAppTopics)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.findApp(topicId);

        $scope.selectedAppTopics = [];
    })
;
