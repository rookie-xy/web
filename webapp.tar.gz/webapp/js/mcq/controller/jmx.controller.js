angular.module('mcqControllers')

    .controller('messageConsumerQueryCtrl', function ($scope, $timeout, jmxService) {

        $scope.loading = false;
        /**
         * 搜索应用
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有日志
         */
        $scope.search = function () {
            $scope.loading = false;
            
            jmxService.search($scope.query.gatewayHost).success(function (data) {
                if (data.status == 200) {
                    if (data.result != null && data.result.length != 0){
                        $scope.jmx = angular.fromJson(data.result);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: "没有数据"
                        };
                    }

                    $scope.loading = false;
                } else if (data.status == 500) {
                    $scope.jmx = {};
                    $scope.operation = {
                        success: false,
                        message: data.result
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);
                } else {
                    $scope.jmx = {};
                    $scope.operation = {
                        success: false,
                        message: "服务端返回数据不正确"
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);                    
                }
            });
        };

        $scope.jmx = {};
    });
