angular.module('mcqControllers')

    // 查询
    .controller('alarmPolicyQueryCtrl', function ($scope, alarmPolicyService) {
        /**
         * 搜索
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            alarmPolicyService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.alarmPolicies = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

    // 新增窗口
    .controller('alarmPolicyAddModalCtrl', function ($scope, $uibModal) {

        $scope.toAddModal = function () {

            $scope.modalTitle = '新增';

            $scope.alarmPolicy = {
                userType: 'USER',
                alarmLevel: 'NORMAL',
                alarmMode: 'SMS',
                trendValue: 0
            };

            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/alarm_policy/detail.tpl.html',
                controller: 'alarmPolicyAddCtrl',
                scope: $scope
            });
        };

    })

    // 新增
    .controller('alarmPolicyAddCtrl', function ($scope, $uibModalInstance, $timeout, alarmPolicyService) {

        /**
         * 添加
         * @param alarmPolicy 报警类型
         */
        $scope.ok = function (alarmPolicy) {
            $scope.confirmDisabled = true;

            alarmPolicyService.add(alarmPolicy)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '添加成功'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '添加失败'
                    };
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    .controller('alarmPolicyEditModalCtrl', function ($scope, $uibModal) {

        $scope.modalTitle = '编辑';

        $scope.toEditModal = function (id) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/alarm_policy/detail.tpl.html',
                controller: 'alarmPolicyEditCtrl',
                scope: $scope,
                resolve: {
                    alarmPolicyId: id
                }
            });
        };
    })

    .controller('alarmPolicyEditCtrl', function ($scope, $uibModalInstance, $timeout, alarmPolicyService, alarmPolicyId) {
        /**
         * 编辑
         * @param alarmPolicy 报警类型
         */
        $scope.ok = function (alarmPolicy) {
            $scope.confirmDisabled = true;

            alarmPolicyService.update(alarmPolicy)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '编辑成功！'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '编辑失败！'
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };


        alarmPolicyService.findById(alarmPolicyId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.alarmPolicy = data.result;

                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败！'
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败！'
                };
            });

    })

    .controller('alarmPolicyDeleteModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载删除页面
         * @param alarmPolicyId ID标识
         */
        $scope.toDeleteModal = function (alarmPolicyId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/alarm_policy/delete.tpl.html',
                controller: 'alarmPolicyDeleteCtrl',
                scope: $scope,
                resolve: {
                    alarmPolicyId: alarmPolicyId
                }
            });
        };
    })

    // 删除应用
    .controller('alarmPolicyDeleteCtrl', function ($scope, $uibModalInstance, $timeout, alarmPolicyService, alarmPolicyId) {
        /**
         * 删除应用
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;

            alarmPolicyService.delete(alarmPolicyId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);

                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    // 启用/禁用
    .controller('alarmPolicyLifeCtrl', function ($scope, alarmPolicyService) {
        /**
         * 禁用
         * @param id 报警类型ID
         */
        $scope.disable = function (id) {
            alarmPolicyService.disable(id).success(
                function (data) {
                    if (data.status == 200) {
                        $scope.search();
                    }
                }
            );
        };

        /**
         * 启用
         * @param id 报警类型ID
         */
        $scope.enable = function (id) {
            alarmPolicyService.enable(id).success(
                function (data) {
                    if (data.status == 200) {
                        $scope.search();
                    }
                }
            )
        };
    })

    // 选择指标弹出层
    .controller('alarmTypeSelectModalCtrl', function ($scope, $uibModal) {

        $scope.toSelectModal = function () {
            var modalInstance = $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg',
                templateUrl: 'views/alarm_policy/select_alarm_type.tpl.html',
                controller: 'alarmTypeSelectCtrl'
            });

            // 基于promise api，向策略设置指标信息
            modalInstance.result.then(function (selectedAlarmType) {
                $scope.alarmPolicy.alarmTypeId = selectedAlarmType.id;
                $scope.alarmPolicy.alarmTypeName = selectedAlarmType.name;
            });
        };

    })

    // 应用选择弹出层处理逻辑
    .controller('alarmTypeSelectCtrl', function ($scope, $uibModalInstance, alarmTypeService) {

        // 存储选择的应用
        $scope.selected = {alarmType: null};

        $scope.ok = function () {
            // 向父页面传递数据
            $uibModalInstance.close($scope.selected.alarmType);
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            alarmTypeService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.alarmTypes = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);

    })

    // 选择应用弹出层
    .controller('alarmPolicyAppSelectModalCtrl', function ($scope, $uibModal) {

        $scope.toSelectModal = function () {
            var modalInstance = $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg',
                templateUrl: 'views/alarm_policy/select_app.tpl.html',
                controller: 'alarmPolicyAppSelectCtrl'
            });

            // 基于promise api，向策略设置生效应用信息
            modalInstance.result.then(function (selectedApp) {
                $scope.alarmPolicy.appId = selectedApp.id;
                $scope.alarmPolicy.appCode = selectedApp.code;
            });
        };

    })

    // 应用选择弹出层处理逻辑
    .controller('alarmPolicyAppSelectCtrl', function ($scope, $uibModalInstance, appService) {

        // 存储选择的应用
        $scope.selected = {app: null};

        $scope.ok = function () {
            // 向父页面传递数据
            $uibModalInstance.close($scope.selected.app);
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            appService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.applications = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);

    })

;