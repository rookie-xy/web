/**
 * broker管理Controller
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqControllers')
    // 查询
    .controller('brokerQueryCtrl', function ($scope, brokerService) {
        /**
         * 搜索broker
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有broker
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            brokerService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.brokers = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

    // 加载添加页面
    .controller('brokerAddModalCtrl', function ($scope, $uibModal) {

        $scope.modalTitle = '新增';

        $scope.toAddModal = function () {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/broker/detail.tpl.html',
                controller: 'brokerAddCtrl',
                scope: $scope
            });
        };
    })

    // 添加
    .controller('brokerAddCtrl', function ($scope, $timeout, $uibModalInstance, brokerService) {

        $scope.broker = {role: 1};

        /**
         * 新增broker
         * @param broker
         */
        $scope.ok = function (broker) {
            $scope.confirmDisabled = true;
            brokerService.add(broker)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '新增成功'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '新增失败'
                    };
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    // 加载编辑页面
    .controller('brokerEditModalCtrl', function ($scope, $uibModal) {

        $scope.modalTitle = '编辑';

        $scope.toEditModal = function (brokerId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/broker/detail.tpl.html',
                controller: 'brokerEditCtrl',
                scope: $scope,
                resolve: {
                    brokerId: brokerId
                }
            });
        };
    })

    // 编辑
    .controller('brokerEditCtrl', function ($scope, $timeout, $uibModalInstance, brokerService, brokerId) {

        /**
         * 编辑
         * @param broker
         */
        $scope.ok = function (broker) {
            $scope.confirmDisabled = true;
            brokerService.update(broker)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "编辑成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": '编辑失败'
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        brokerService.findById(brokerId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.broker = data.result;

                    $scope.operation = null;
                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败'
                    };
                }
            });

    })

    // 加载删除页面
    .controller('brokerDeleteModalCtrl', function ($scope, $uibModal) {
        $scope.toDeleteModal = function (brokerId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/broker/delete.tpl.html',
                controller: 'brokerDeleteCtrl',
                scope: $scope,
                resolve: {
                    brokerId: brokerId
                }
            });
        };
    })

    // 删除
    .controller('brokerDeleteCtrl', function ($scope, $timeout, $uibModalInstance, brokerService, brokerId) {
        /**
         * 删除
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;
            brokerService.delete(brokerId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    });
