angular.module('mcqControllers')
// 消费者连接弹出层
    .controller('consumerConnectionModalCtrl', function ($scope, $uibModal) {

        $scope.toListModal = function (appCode, topicCode) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/monitor/connection/detail.tpl.html',
                controller: 'consumerConnectionCtrl',
                resolve: {
                    appTopic: function () {
                        return {
                            appCode: appCode,
                            topicCode: topicCode
                        };
                    }
                }
            });
        }

    })

    .controller('consumerConnectionCtrl', function ($scope, $uibModalInstance, connectionService, appTopic) {

        // 取消
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.loading = true;

        connectionService.findConsumer(appTopic.appCode, appTopic.topicCode)
            .success(function (response) {

                if (response.status == 200) {
                    $scope.connections = response.result;
                    $scope.operation = {
                        success: true,
                        message: '数据加载成功'
                    };
                    $scope.loading = false;
                } else {
                    $scope.operation = {
                        success: false,
                        message: response.message
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败'
                };
            });

    })


    // 生产者连接弹出层
    .controller('producerConnectionModalCtrl', function ($scope, $uibModal) {

        $scope.toListModal = function (appCode, topicCode) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/monitor/connection/detail.tpl.html',
                controller: 'producerConnectionCtrl',
                resolve: {
                    connectionQuery: function () {
                        return {
                            appCode: appCode,
                            topicCode: topicCode
                        };
                    }
                }
            });
        }

    })

    .controller('producerConnectionCtrl', function ($scope, $uibModalInstance, connectionService, connectionQuery) {

        // 取消
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.loading = true;

        connectionService.findProducer(connectionQuery.appCode, connectionQuery.topicCode)
            .success(function (response) {

                if (response.status == 200) {
                    $scope.connections = response.result;
                    $scope.operation = {
                        success: true,
                        message: '数据加载成功'
                    };
                    $scope.loading = false;
                } else {
                    $scope.operation = {
                        success: false,
                        message: response.message
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败'
                };
            });

    })


;