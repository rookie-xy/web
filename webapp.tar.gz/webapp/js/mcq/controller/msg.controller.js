/**
 * 消息监控的Controller
 * @type {angular.Module}
 * @author zhangxiaodong01
 */
angular.module('mcqControllers')
    
    .controller('msgModalCtrl', function ($scope, $uibModal) {

        $scope.toListModal = function (appCode, topicCode) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/msg/list.tpl.html',
                controller: 'msgQueryCtrl',
                size: 'lg8',
                resolve: {
                    appTopic: function () {
                        return {
                            appCode: appCode,
                            topicCode: topicCode
                        };
                    }
                }
            });
        }

    })

    .controller('msgQueryCtrl', function ($scope, $timeout, $uibModalInstance, msgService, appTopic) {
        $scope.bQuery = {};
        // 取消
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        /**
         * 根据消息KEY搜索消息
         */
        $scope.searchByKey = function () {
            $scope.loading = true;

            if ($scope.bQuery.msgKey == null || $scope.bQuery.msgKey == "undefined" || $scope.bQuery.msgKey == undefined) {
                $scope.msgList = {};
                $scope.operation = {
                    success: false,
                    message: "请填写消息KEY!"
                };
                $timeout(function () {
                    $scope.operation = null;
                }, 1000);
                return;
            }

            $scope.bQuery.topicCode = appTopic.topicCode;

            msgService.searchByKey($scope.bQuery).success(function (data) {
                if (data != null && data.status == 200) {
                    $scope.msgList = data.result;
                    $scope.loading = false;
                } else if (data != null && (data.status == 500 || data.status == 300)) {
                    $scope.msgList = {};
                    $scope.operation = {
                        success: false,
                        message: data.message
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);
                } else {
                    $scope.msgList = {};
                    $scope.operation = {
                        success: false,
                        message: "服务端返回数据不正确"
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);
                }
                $scope.loading = false;

            });
        };

        /**
         *  根据消息ID搜索消息
         */
        $scope.searchById = function () {
            $scope.loading = true;

            if ($scope.bQuery.id == null || $scope.bQuery.id == "undefined" || $scope.bQuery.id == undefined) {
                $scope.msgs = {};
                $scope.operation = {
                    success: false,
                    message: "请填写消息ID!"
                };
                $timeout(function () {
                    $scope.operation = null;
                }, 1000);
                return;
            }

            msgService.searchById($scope.bQuery).success(function (data) {
                if (data != null && data.status == 200) {
                    $scope.msgs = data.result;
                    $scope.loading = false;
                } else if (data != null && (data.status == 500 || data.status == 300)) {
                    $scope.msgs = {};
                    $scope.operation = {
                        success: false,
                        message: data.message
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);
                } else {
                    $scope.msgs = {};
                    $scope.operation = {
                        success: false,
                        message: "服务端返回数据不正确"
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);
                }
                $scope.loading = false;
            })
        }
        

    });

