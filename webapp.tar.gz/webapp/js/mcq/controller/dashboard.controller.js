/**
 * 首页的Controller
 * @type {angular.Module}
 * @author zhangxiaodong01
 */
angular.module('mcqControllers')

    .controller('dashboardQueryCtrl', function ($scope, dashboardService, $filter) {
        // 模板
        $scope.scatterConfigTpl = {
            theme: 'macarons',
            dataLoaded: true
        };

        $scope.scatterOptionTpl = {
            legend: {
                left: 'left',
                data: []
            },
            tooltip: {
                trigger: 'axis',
                position: function (pt) {
                    return [pt[0], '10%'];
                }
            },
            toolbox: {
                feature: {
                    dataZoom: {
                        yAxisIndex: 'none'
                    },
                    restore: {},
                    saveAsImage: {}
                }
            },
            title: {
                left: 'center',
                text: ''
            },
            xAxis: {
                type: 'category',
                boundaryGap: false
            },
            yAxis: {
                type: 'value',
                boundaryGap: [0, '100%']
            }
        };


        /**
         * 构建sum与tps指标统计图
         * @param datum
         */
        var buildSumTpsMetricOptions = function (metrics, role) {
            //数据处理
            var pattern = 'MM/dd';
            var serieSumList = [], serieTpsList=[], timeList = [], sumList = [], tpsList= [];
            var isEmptyArray = true;

            for (var i = 0; i < metrics.length; i++) {
                var time = $filter('date')(metrics[i].timeMetric, pattern);
                if (timeList.indexOf(time) == -1) {
                    timeList.push(time);
                }

                sumList.push(parseInt(metrics[i].sum) == metrics[i].sum ? parseInt(metrics[i].sum) : metrics[i].sum.toFixed(2));
                tpsList.push(parseInt(metrics[i].tps) == metrics[i].tps ? parseInt(metrics[i].tps) : metrics[i].tps.toFixed(2));

                isEmptyArray = false;
            }

            var serieRolePrefix  = "";
            if (role == "produce") {
                serieRolePrefix = "生产";
            } else {
                serieRolePrefix = "消费";
            }
            
            var serieSum = {
                'name': serieRolePrefix + "消息总数",
                'type': 'line',
                'smooth': true,
                'symbol': 'none',
                'sampling': 'average',
                'data': !isEmptyArray ? sumList : null
            };
            serieSumList.push(serieSum);

            var serieTps = {
                'name': serieRolePrefix + "TPS",
                'type': 'line',
                'smooth': true,
                'symbol': 'none',
                'sampling': 'average',
                'data': !isEmptyArray ? tpsList : null
            };
            serieTpsList.push(serieTps);
            //渲染sum统计图表
            if (role == "produce") {
                $scope.produceSumScatterConfig = _.cloneDeep($scope.scatterConfigTpl);
                $scope.produceSumScatterOption = _.cloneDeep($scope.scatterOptionTpl);
                $scope.produceSumScatterOption.title.text = serieRolePrefix + "消息总数";
                $scope.produceSumScatterOption.xAxis.data = timeList;
                $scope.produceSumScatterOption.legend.data = [];
                $scope.produceSumScatterOption.series = serieSumList;
                //渲染tps统计图表
                $scope.produceTpsScatterConfig = _.cloneDeep($scope.scatterConfigTpl);
                $scope.produceTpsScatterOption = _.cloneDeep($scope.scatterOptionTpl);
                $scope.produceTpsScatterOption.title.text = serieRolePrefix + "TPS";
                $scope.produceTpsScatterOption.xAxis.data = timeList;
                $scope.produceTpsScatterOption.legend.data = ['tps'];
                $scope.produceTpsScatterOption.series = serieTpsList;    
            } else {
                $scope.consumeSumScatterConfig = _.cloneDeep($scope.scatterConfigTpl);
                $scope.consumeSumScatterOption = _.cloneDeep($scope.scatterOptionTpl);
                $scope.consumeSumScatterOption.title.text = serieRolePrefix + "消息总数";
                $scope.consumeSumScatterOption.xAxis.data = timeList;
                $scope.consumeSumScatterOption.legend.data = [];
                $scope.consumeSumScatterOption.series = serieSumList;
                //渲染tps统计图表
                $scope.consumeTpsScatterConfig = _.cloneDeep($scope.scatterConfigTpl);
                $scope.consumeTpsScatterOption = _.cloneDeep($scope.scatterOptionTpl);
                $scope.consumeTpsScatterOption.title.text = serieRolePrefix + "TPS";
                $scope.consumeTpsScatterOption.xAxis.data = timeList;
                $scope.consumeTpsScatterOption.legend.data = ['tps'];
                $scope.consumeTpsScatterOption.series = serieTpsList;   
            }
        };

        $scope.queryMetrics = function () {
            dashboardService.queryMessageCountMetrics("produce")
                .success(function (response) {
                    if (response.status == 200) {
                        buildSumTpsMetricOptions(response.result, "produce");
                    }
                });

            dashboardService.queryMessageCountMetrics("custome")
                .success(function (response) {
                    if (response.status == 200) {
                        buildSumTpsMetricOptions(response.result, "custome");
                    }
                });
        };

        $scope.queryMetrics();
    })
