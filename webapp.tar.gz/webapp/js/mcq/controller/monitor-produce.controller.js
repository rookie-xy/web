angular.module('mcqControllers')
    // 查询
    .controller('produceMonitorQueryCtrl', function ($scope, produceMonitorService) {

        /**
         * 搜索
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            produceMonitorService.search(aQuery, pagination)
                .success(function (response) {
                    if (response.status == 200) {
                        if (pageNo) {
                            $scope.paginationConf.pageNo = pageNo;
                        }
                        $scope.paginationConf.totalRecord = response.pagination.totalRecord;
                        $scope.produceMonitors = response.result;
                        $scope.operation = {
                            success: true,
                            message: '数据加载成功'
                        };
                    } else {
                        $scope.operation = {
                            success: false,
                            message: '数据加载发生错误'
                        };
                    }
                    $scope.loading = false;
                });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);

    })

    // 生产明细弹出层
    .controller('produceDetailModalCtrl', function ($scope, $uibModal) {

        $scope.toListModal = function (produceMonitor) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg',
                templateUrl: 'views/monitor/produce/detail.tpl.html',
                controller: 'produceDetailCtrl',
                resolve: {
                    produceMonitor: function () {
                        return produceMonitor
                    }
                }
            });
        }
    })

    // 生产明细
    .controller('produceDetailCtrl', function ($scope, $uibModalInstance, produceMonitor) {

        // 取消
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.produceMonitor = produceMonitor;

    })

    .controller('produceStatsModalCtrl', function ($scope, $uibModal) {

        $scope.toListModal = function (topicCode) {
            var appTopicCode = new Object();
            appTopicCode.appCode = "";
            appTopicCode.topicCode = topicCode;
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg8',
                templateUrl: 'views/monitor/produce/stats.tpl.html',
                controller: 'produceStatsCtrl',
                scope: $scope,
                resolve: {
                    appTopicCode: appTopicCode
                }
            });
        }
        // 模板
        $scope.scatterConfigTpl = {
            theme: 'macarons',
            dataLoaded: true
        };

        $scope.scatterOptionTpl = {
            legend: {
                left: 'left',
                data: []
            },
            tooltip: {
                trigger: 'axis',
                position: function (pt) {
                    return [pt[0], '10%'];
                }
            },
            toolbox: {
                feature: {
                    dataZoom: {
                        yAxisIndex: 'none'
                    },
                    restore: {},
                    saveAsImage: {}
                }
            },
            title: {
                left: 'center',
                text: ''
            },
            xAxis: {
                type: 'category',
                boundaryGap: false
            },
            yAxis: {
                type: 'value',
                boundaryGap: [0, '100%']
            }
        };

    })

    .controller('produceStatsCtrl', function ($scope, $uibModalInstance, appTopicCode, produceMonitorService, $filter) {
        var topicCode = appTopicCode.topicCode;
        // 取消
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        /**
         * 构建sum与tps指标统计图
         * @param datum
         */
        var buildSumTpsMetricOptions = function (metrics) {
            //数据处理
            var pattern = 'MM/dd';
            var serieSumList = [], serieTpsList=[], timeList = [], sumList = [], tpsList= [];
            var isEmptyArray = true;

            for (var i = 0; i < metrics.length; i++) {
                var time = $filter('date')(metrics[i].timeMetric, pattern);
                if (timeList.indexOf(time) == -1) {
                    timeList.push(time);
                }

                sumList.push(parseInt(metrics[i].sum) == metrics[i].sum ? parseInt(metrics[i].sum) : metrics[i].sum.toFixed(2));
                tpsList.push(parseInt(metrics[i].tps) == metrics[i].tps ? parseInt(metrics[i].tps) : metrics[i].tps.toFixed(2));
                
                isEmptyArray = false;
            }

            var serieSum = {
                'name': "消息总数",
                'type': 'line',
                'smooth': true,
                'symbol': 'none',
                'sampling': 'average',
                'data': !isEmptyArray ? sumList : null
            };
            serieSumList.push(serieSum);

            var serieTps = {
                'name': "TPS",
                'type': 'line',
                'smooth': true,
                'symbol': 'none',
                'sampling': 'average',
                'data': !isEmptyArray ? tpsList : null
            };
            serieTpsList.push(serieTps);
            //渲染sum统计图表
            $scope.sumScatterConfig = _.cloneDeep($scope.scatterConfigTpl);
            $scope.sumScatterOption = _.cloneDeep($scope.scatterOptionTpl);
            $scope.sumScatterOption.title.text = "消息总数";
            $scope.sumScatterOption.xAxis.data = timeList;
            $scope.sumScatterOption.legend.data = [];
            $scope.sumScatterOption.series = serieSumList;
            //渲染tps统计图表
            $scope.tpsScatterConfig = _.cloneDeep($scope.scatterConfigTpl);
            $scope.tpsScatterOption = _.cloneDeep($scope.scatterOptionTpl);
            $scope.tpsScatterOption.title.text = "TPS";
            $scope.tpsScatterOption.xAxis.data = timeList;
            $scope.tpsScatterOption.legend.data = ['tps'];
            $scope.tpsScatterOption.series = serieTpsList;

        };

        $scope.queryMetrics = function () {

            produceMonitorService.queryProduceMetrics(topicCode)
                .success(function (response) {
                    if (response.status == 200) {
                        buildSumTpsMetricOptions(response.result);
                    }
                });
        };
        
        $scope.queryMetrics();
    })


;