/**
 * Topic的Broker分布模块
 *
 * @author zhuchunlai
 */
angular.module('mcqControllers')

    // 加载Broker分布页面
    .controller('topicBrokerViewModalCtrl', function ($scope, $uibModal) {

        $scope.toModal = function (topicId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/topic_broker/detail.tpl.html',
                controller: 'topicBrokerViewCtrl',
                scope: $scope,
                resolve: {
                    topicId: topicId
                }
            });
        };
    })

    // Broker分布
    .controller('topicBrokerViewCtrl', function ($scope, $uibModalInstance, brokerService, topicId) {
        /**
         * 查询指定Topic分配的Broker列表
         * @param topicId topic标识
         */
        $scope.findBroker = function (topicId) {
            brokerService.findByTopic(topicId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.topicBrokers = data.result;

                        $scope.operation = {
                            "success": true,
                            "message": "查询成功"
                        };
                    } else {
                        $scope.operation = {
                            success: false,
                            message: '数据加载失败'
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败'
                    };
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.findBroker(topicId);
    })

    // 分配Broker弹出层
    .controller('topicBrokerManageModalCtrl', function ($scope, $uibModal) {

        $scope.toModal = function (topicId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg',
                templateUrl: 'views/topic_broker/manage.tpl.html',
                controller: 'topicBrokerManageCtrl',
                scope: $scope,
                resolve: {
                    topicId: topicId
                }
            });
        };
    })

    // 分配Broker
    .controller('topicBrokerManageCtrl', function ($scope, $q, $timeout, $uibModalInstance, brokerService, topicService, topicId) {
        var operation = null;
        var topicBrokers, brokers;

        $q.all({
            first: brokerService.findByTopic(topicId),
            second: brokerService.findAll()
        })
            .then(function (responseArray) {
                var topicBrokerResponse = responseArray['first'];
                var brokerResponse = responseArray['second'];

                // http状态码不是200
                if (topicBrokerResponse.status != 200 || brokerResponse.status != 200) {
                    operation = {
                        success: false,
                        message: '数据加载失败'
                    };
                } else {
                    var topicBrokersRespEntity = topicBrokerResponse.data;
                    var brokersRespEntity = brokerResponse.data;

                    // 业务层面上的状态不是200，即发生业务错误
                    if (topicBrokersRespEntity.status != 200 || brokersRespEntity.status != 200) {
                        operation = {
                            success: false,
                            message: '数据加载失败'
                        };
                    } else {
                        topicBrokers = topicBrokersRespEntity.result;
                        brokers = brokersRespEntity.result;

                        // 剔除已经分配给Topic的broker
                        var broker;
                        for (var i = brokers.length - 1; i >= 0; i--) {
                            broker = brokers[i];
                            for (var j = 0, length = topicBrokers.length; j < length; j++) {
                                if (broker.id == topicBrokers[j].id) {
                                    brokers.splice(i, 1);
                                    break;
                                }
                            }
                        }

                        for (var i = 0, j = topicBrokers.length; i < j; i++) {
                            topicBrokers[i]['removeDisabled'] = true;
                        }
                        for (var i = 0, j = brokers.length; i < j; i++) {
                            brokers[i]['removeDisabled'] = false;
                        }

                        $scope.brokers = brokers;
                        $scope.selectedBrokers = topicBrokers;
                    }
                }

                if (operation != null) {
                    $scope.operation = operation;
                }
            });

        /**
         * 从已选列表中删除
         * @param index 已选列表索引
         * @param broker 删除的Broker
         */
        $scope.removeBroker = function (index, broker) {
            $scope.selectedBrokers.splice(index, 1);
            $scope.brokers.push(broker);
        };

        /**
         * 从候选列表中选择Broker
         * @param index 候选列表索引
         * @param broker 选择的Broker
         */
        $scope.selectBroker = function (index, broker) {
            $scope.brokers.splice(index, 1);
            $scope.selectedBrokers.push(broker);
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        /**
         * 修改Topic的Broker分布
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;

            var brokers = $scope.selectedBrokers;

            topicService.allocateBroker(topicId, brokers)
                .success(function (response) {
                    if (response.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '操作成功'
                        };

                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: response.message
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '操作失败'
                    };
                });

        }
    })


;