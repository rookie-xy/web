/**
 * 报警事件管理Controller
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqControllers')

// 查询
    .controller('alarmEventQueryCtrl', function ($scope, $filter, alarmEventService) {

        /**
         * 搜索报警事件
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有事件
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };

            var aQuery = query ? query : $scope.query;
            // 拷贝数据,避免后续的修改影响scope中的数据
            aQuery = angular.copy(aQuery);

            if (aQuery) {
                if (aQuery.beginTime) {
                    aQuery.beginTime = $filter('date')(aQuery.beginTime, 'yyyy-MM-dd');
                }
                if (aQuery.endTime) {
                    aQuery.endTime = $filter('date')(aQuery.endTime, 'yyyy-MM-dd');
                }
            }

            alarmEventService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.alarmEvents = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })
;
