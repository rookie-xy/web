/**
 * 用户管理模块的Controller
 * @type {angular.Module}
 * @author zhuchunlai
 */
angular.module('mcqControllers')
    // 查询
    .controller('userQueryCtrl', function ($scope, userService) {

        /**
         * 搜索
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有用户
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            userService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.users = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

    // 启用/禁用
    .controller('userLifeCtrl', function ($scope, userService) {
        /**
         * 禁用用户
         * @param id 用户ID
         */
        $scope.disable = function (id) {
            userService.disable(id).success(
                function (data) {
                    if (data.status == 200) {
                        $scope.search();
                    }
                }
            );
        };

        /**
         * 启用用户
         * @param id 用户ID
         */
        $scope.enable = function (id) {
            userService.enable(id).success(
                function (data) {
                    if (data.status == 200) {
                        $scope.search();
                    }
                }
            )
        };
    })

    .controller('userDetailModalCtrl', function ($scope, $uibModal) {

        /**
         * 加载编辑页面
         *
         * @param userId 用户标识
         * @param options 选项，支持：reload<Boolean>, editModal<Boolean>, profileModal<Boolean>, detailModal<Boolean>
         */
        $scope.toDetailModal = function (userId, options) {

            var aOptions = {reload: false, editModal: false, profileModal: false, detailModal: false, title: '编辑'};
            angular.extend(aOptions, options);

            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/user/detail.tpl.html',
                controller: 'userEditCtrl',
                scope: $scope,
                resolve: {
                    userId: userId,
                    options: aOptions
                }
            });
        };

    })

    // 编辑
    .controller('userEditCtrl', function ($scope, $uibModalInstance, $timeout, userService, userId, options) {
        /**
         * 编辑用户
         * @param user 用户
         */
        $scope.ok = function (user) {
            $scope.confirmDisabled = true;
            // 更新用户
            delete user.roles;
            
            userService.update(user)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "编辑成功"
                        };

                        $timeout(function () {
                            $scope.cancel();
                            if (options.reload) {
                                $scope.search();
                            }
                        }, 1000);
                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": '编辑失败'
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };


        userService.findById(userId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.user = data.result;
                    $scope.roles = [
                        {id: 'USER', name: '普通用户'},
                        {id: 'OPERATOR', name: '运维'},
                        {id: 'ADMIN', name: '管理员'}
                    ];
                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败！'
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败！'
                };
            });

        $scope.options = options;

    })
;
