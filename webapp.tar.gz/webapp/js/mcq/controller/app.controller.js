/**
 * 应用管理Controller
 * @type {angular.Module}
 * @author zhuchunlai, zhufei
 */
angular.module('mcqControllers')

    // 查询
    .controller('appQueryCtrl', function ($scope, appService) {

        /**
         * 搜索应用
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有用户
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            appService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.applications = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

    .controller('appEditModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载编辑页面
         * @param appId 应用标识
         */
        $scope.toEditModal = function (appId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/app/edit.tpl.html',
                controller: 'appEditCtrl',
                scope: $scope,
                resolve: {
                    appId: appId
                }
            });
        };
    })

    // 编辑应用
    .controller('appEditCtrl', function ($scope, $uibModalInstance, $timeout, appService, appId) {
        /**
         * 编辑应用
         * @param app 应用
         */
        $scope.ok = function (app) {
            $scope.confirmDisabled = true;
            var memberEmails = app.memberEmails;
            if (memberEmails) {
                if (!Array.isArray(memberEmails)) {
                    var values = memberEmails.split(/[,，\r\n]/);
                    var emails = "";
                    var email;
                    for (var i = 0, j = values.length; i < j; i++) {
                        email = values[i].trim();
                        if (email && email.length > 0) {
                            if (i > 0) {
                                emails += ",";
                            }
                            emails += email;
                        }
                    }
                    app.memberEmails = emails;
                } else {
                    app.memberEmails = memberEmails.toString();
                }
            }

            appService.update(app)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '编辑成功！'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '编辑失败！'
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };


        appService.findById(appId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.app = data.result;

                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败！'
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败！'
                };
            });

    })

    .controller('appDeleteModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载删除页面
         * @param appId 应用标识
         */
        $scope.toDeleteModal = function (appId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/app/delete.tpl.html',
                controller: 'appDeleteCtrl',
                scope: $scope,
                resolve: {
                    appId: appId
                }
            });
        };
    })

    // 删除应用
    .controller('appDeleteCtrl', function ($scope, $uibModalInstance, $timeout, appService, appId) {
        /**
         * 删除应用
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;
            appService.delete(appId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);

                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

;
