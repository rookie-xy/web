/**
 * 任务管理Controller
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqControllers')

// 查询
    .controller('taskQueryCtrl', function ($scope, taskService) {

        /**
         * 搜索任务
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有用户
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            taskService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.tasks = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
        $scope.status = [
            {id: 0, name: '新增'},
            {id: 1, name: '已派发'},
            {id: 2, name: '执行中'},
            {id: 3, name: '成功'},
            {id: 4, name: '失败不重试'},
            {id: 5, name: '禁用'},
            {id: 6, name: '失败重试'}];
    })

    // 加载添加页面
    .controller('taskAddModalCtrl', function ($scope, $uibModal) {

        $scope.task = {daemons: true, retry: true};

        $scope.modalTitle = '新增';

        $scope.toAddModal = function () {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/task/detail.tpl.html',
                controller: 'taskAddCtrl',
                scope: $scope
            });
        };
    })

    // 添加
    .controller('taskAddCtrl', function ($scope, $timeout, $uibModalInstance, taskService) {
        /**
         * 新增task
         * @param task 任务信息
         */
        $scope.ok = function (task) {
            $scope.confirmDisabled = true;
            taskService.add(task)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '新增成功'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '新增失败'
                    };
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    .controller('taskEditModalCtrl', function ($scope, $uibModal) {

        $scope.modalTitle = '编辑';

        /**
         * 加载编辑页面
         * @param id 任务标识
         */
        $scope.toEditModal = function (id) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/task/detail.tpl.html',
                controller: 'taskEditCtrl',
                scope: $scope,
                resolve: {
                    taskId: id
                }
            });
        };
    })

    // 编辑任务
    .controller('taskEditCtrl', function ($scope, $uibModalInstance, $timeout, taskService, taskId) {
        /**
         * 编辑任务
         * @param task 任务
         */
        $scope.ok = function (task) {
            $scope.confirmDisabled = true;

            taskService.update(task)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '编辑成功！'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '编辑失败！'
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };


        taskService.findById(taskId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.task = data.result;

                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败！'
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败！'
                };
            });

    })

    .controller('taskDeleteModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载删除页面
         * @param taskId 任务标识
         */
        $scope.toDeleteModal = function (taskId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/task/delete.tpl.html',
                controller: 'taskDeleteCtrl',
                scope: $scope,
                resolve: {
                    taskId: taskId
                }
            });
        };
    })

    // 删除任务
    .controller('taskDeleteCtrl', function ($scope, $uibModalInstance, $timeout, taskService, taskId) {
        /**
         * 删除任务
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;
            taskService.delete(taskId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);

                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    .controller('taskErrorModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载错误明细弹出层
         * @param task 任务
         */
        $scope.toErrorModal = function (task) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg',
                templateUrl: 'views/task/error.tpl.html',
                controller: 'taskErrorCtrl',
                resolve: {
                    task: task
                }
            });
        };
    })

    .controller('taskErrorCtrl', function ($scope, $uibModalInstance, task) {

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.taskDetail = task;
    })

;
