/**
 * 接入申请模块控制器
 * @type {angular.Module}
 * @author zhuchunlai
 */
angular.module("mcqControllers")

// 查询
    .controller('applyQueryCtrl', function ($scope, applyService) {

        /**
         * 搜索
         * @param pageNo 当前页码
         * @param query 搜索条件
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            applyService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.applies = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };
        $scope.types = [{id: 1, name: '生产'}, {id: 2, name: '消费'}];

        $scope.search(1);
    })

    // 添加申请
    .controller("applyAddCtrl", function ($scope, $timeout, $filter, applyService) {

        /**
         * 添加申请
         * @param apply
         */
        $scope.add = function (apply) {
            $scope.confirmDisabled = true;

            // 转换日期格式
            var onlineDate = new Date(apply.onlineDate);
            apply.onlineDate = $filter('date')(onlineDate, 'yyyy-MM-dd');

            applyService.add(apply)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '申请已受理，请等待处理结果'
                        };
                        $scope.reset();

                        $timeout(function () {
                            $scope.currentStep = 0;
                            $scope.operation = null;
                            $scope.confirmDisabled = false;
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: '申请失败，' + data.message
                        };

                        $scope.confirmDisabled = false;
                    }
                })
                .error(function (data) {
                    $scope.operation = {
                        success: false,
                        message: '申请失败，' + data
                    };

                    $scope.confirmDisabled = false;
                });
        };

        /**
         * 下一步
         */
        $scope.nextStep = function () {
            $scope.currentStep++;
        };

        /**
         * 上一步
         */
        $scope.previousStep = function () {
            $scope.currentStep--;
        };

        /**
         * 修改接入类型，重置数据
         */
        $scope.changeType = function () {
            $scope.apply.connectMode = 'CLIENT';
        };

        /**
         * 修改应用类型，重置数据
         */
        $scope.changeAppType = function () {
            $scope.apply.appId = 0;
            $scope.apply.appCode = null;
            $scope.apply.appName = null;
            $scope.apply.appLeaderEmail = null;
            $scope.apply.appMemberEmails = null;
        };

        /**
         * 修改topic类型，重置数据
         */
        $scope.changeTopicType = function () {
            $scope.apply.topicId = 0;
            $scope.apply.topicCode = null;
            $scope.apply.topicName = null;
        };

        /**
         * 重置申请数据
         */
        $scope.reset = function () {
            $scope.apply = {appType: 1, topicType: 1, type: 1, connectMode: 'CLIENT', appId: 0, topicId: 0};
        };

        // 初始化起始步骤
        $scope.currentStep = 0;

        $scope.reset();
    })

    // 查看进展
    .controller('applyProcessModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载申请处理进展页面
         * @param apply 申请
         */
        $scope.toProcessModal = function (apply) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/apply/process.tpl.html',
                controller: 'applyProcessCtrl',
                resolve: {
                    apply: apply
                }
            });

        };
    })

    .controller('applyProcessCtrl', function ($scope, $uibModalInstance, applyService, apply) {

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.failedReason = apply.failedReason;

    })

    // 选择应用弹出层
    .controller('appSelectModalCtrl', function ($scope, $uibModal) {

        $scope.toSelectModal = function () {
            var modalInstance = $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg',
                templateUrl: 'views/apply/select_app.tpl.html',
                controller: 'appSelectCtrl'
            });

            // 基于promise api，向申请设置选择的应用信息
            modalInstance.result.then(function (selectedApp) {
                $scope.apply.appId = selectedApp.id;
                $scope.apply.appCode = selectedApp.code;
                $scope.apply.appName = selectedApp.name;
                $scope.apply.appLeaderEmail = selectedApp.leaderEmail;
            });
        };

    })

    // 应用选择弹出层处理逻辑
    .controller('appSelectCtrl', function ($scope, $uibModalInstance, appService) {

        // 存储选择的应用
        $scope.selected = {app: null};

        $scope.ok = function () {
            // 向父页面传递数据
            $uibModalInstance.close($scope.selected.app);
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            appService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.applications = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);

    })

    // 选择Topic弹出层
    .controller('topicSelectModalCtrl', function ($scope, $uibModal) {

        $scope.toSelectModal = function () {
            var modalInstance = $uibModal.open({
                backdrop: false,
                keyboard: false,
                size: 'lg',
                templateUrl: 'views/apply/select_topic.tpl.html',
                controller: 'topicSelectCtrl'
            });

            // 基于promise api，向申请设置选择的Topic信息
            modalInstance.result.then(function (selectedTopic) {
                $scope.apply.topicId = selectedTopic.id;
                $scope.apply.topicCode = selectedTopic.code;
                $scope.apply.topicName = selectedTopic.name;
            });
        };

    })

    .controller('topicSelectCtrl', function ($scope, $uibModalInstance, topicService) {
        // 存储选择的topic
        $scope.selected = {topic: null};

        $scope.ok = function () {
            // 向父页面传递数据
            $uibModalInstance.close($scope.selected.topic);
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;


            topicService.searchDictionary(aQuery, pagination).success(function (data) {
                if (pageNo) {
                    $scope.paginationConf.pageNo = pageNo;
                }
                $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                $scope.dictionaries = data.result;
                $scope.loading = false;
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

;