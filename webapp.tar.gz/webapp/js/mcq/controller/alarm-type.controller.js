angular.module('mcqControllers')

    // 查询
    .controller('alarmTypeQueryCtrl', function ($scope, alarmTypeService) {
        /**
         * 搜索
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            alarmTypeService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.alarmTypes = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    })

    // 新增窗口
    .controller('alarmTypeAddModalCtrl', function ($scope, $uibModal) {

        $scope.toAddModal = function () {

            $scope.modalTitle = '新增';

            $scope.alarmType = {
                userType: 'USER'
            };

            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/alarm_type/detail.tpl.html',
                controller: 'alarmTypeAddCtrl',
                scope: $scope
            });
        };

    })

    // 新增
    .controller('alarmTypeAddCtrl', function ($scope, $uibModalInstance, $timeout, alarmTypeService) {

        /**
         * 添加
         * @param alarmType 报警类型
         */
        $scope.ok = function (alarmType) {
            $scope.confirmDisabled = true;

            alarmTypeService.add(alarmType)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '添加成功'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '添加失败'
                    };
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    .controller('alarmTypeEditModalCtrl', function ($scope, $uibModal) {

        $scope.modalTitle = '编辑';

        $scope.toEditModal = function (id) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/alarm_type/detail.tpl.html',
                controller: 'alarmTypeEditCtrl',
                scope: $scope,
                resolve: {
                    alarmTypeId: id
                }
            });
        };
    })

    .controller('alarmTypeEditCtrl', function ($scope, $uibModalInstance, $timeout, alarmTypeService, alarmTypeId) {
        /**
         * 编辑
         * @param alarmType 报警类型
         */
        $scope.ok = function (alarmType) {
            $scope.confirmDisabled = true;

            alarmTypeService.update(alarmType)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '编辑成功！'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '编辑失败！'
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };


        alarmTypeService.findById(alarmTypeId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.executor = data.result;

                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败！'
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败！'
                };
            });

    })

    .controller('alarmTypeDeleteModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载删除页面
         * @param alarmTypeId ID标识
         */
        $scope.toDeleteModal = function (alarmTypeId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/alarm_type/delete.tpl.html',
                controller: 'alarmTypeDeleteCtrl',
                scope: $scope,
                resolve: {
                    alarmTypeId: alarmTypeId
                }
            });
        };
    })

    // 删除应用
    .controller('alarmTypeDeleteCtrl', function ($scope, $uibModalInstance, $timeout, alarmTypeService, alarmTypeId) {
        /**
         * 删除应用
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;

            alarmTypeService.delete(alarmTypeId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);

                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    // 启用/禁用
    .controller('alarmTypeLifeCtrl', function ($scope, alarmTypeService) {
        /**
         * 禁用
         * @param id 报警类型ID
         */
        $scope.disable = function (id) {
            alarmTypeService.disable(id).success(
                function (data) {
                    if (data.status == 200) {
                        $scope.search();
                    }
                }
            );
        };

        /**
         * 启用
         * @param id 报警类型ID
         */
        $scope.enable = function (id) {
            alarmTypeService.enable(id).success(
                function (data) {
                    if (data.status == 200) {
                        $scope.search();
                    }
                }
            )
        };
    })

;