/**
 * 网关管理的Controller
 * @type {angular.Module}
 * @author zhangxiaodong01
 */
angular.module('mcqControllers')
// 查询
    .controller('gatewayQueryCtrl', function ($scope, appTopicService) {
        /**
         * 搜索主题
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有消费网关
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;
            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;
            aQuery.connectMode = "GATEWAY";

            appTopicService.search(aQuery, pagination).success(function (data) {
                $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                $scope.appTopics = data.result;
                $scope.loading = false;
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };
        
    })

    //加载删除页面
    .controller('consumerGatewaySwitchCtrl', function ($scope, $uibModal) {
        $scope.toCtrlSwitchModal = function (appTopic, status) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/gateway/consumerUp.tpl.html',
                controller: 'consumerUpCtrl',
                scope: $scope,
                resolve: {
                    param:{"appTopic":appTopic,"status":status}
                }
            });
        }
    })

    .controller('consumerUpCtrl', function ($scope, $uibModalInstance, $timeout, appTopicService, taskService, param) {
        var appTopic = param.appTopic;
        var status = param.status;
        
        if (status == "open") {
            $scope.confirmMessage = "开启消费网关";
        } else if (status == "close") {
            $scope.confirmMessage = "关闭消费网关";
        }
        
        $scope.ok = function () {
            $scope.confirmDisabled = true;
            // 开启消费者
            if (status == "open") {
                appTopicService.enable(appTopic)
                    .success(function (data) {
                       if (data.status == 200) {
                           appTopic.status = 1;
                           $scope.operation = {
                               "success": true,
                               "message": "开启成功"
                           };
                           $timeout(function () {
                               $scope.cancel();
                               $scope.search();
                           }, 1000);

                       } else {
                           $scope.operation = {
                               "success": false,
                               "message": "开启失败"
                           };
                           $timeout(function () {
                               $scope.cancel();
                               $scope.search();
                           }, 1000);
                       }
                    })
                    .error(function () {
                        $scope.operation = {
                            "success": false,
                            "message": "开启操作失败"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    });
            } else if (status == "close") {
                appTopicService.disable(appTopic)
                    .success(function (data) {
                        if (data.status == 200) {
                            appTopic.status = 0;
                            $scope.operation = {
                                "success": true,
                                "message": "关闭成功"
                            };
                            $timeout(function () {
                                $scope.cancel();
                                $scope.search();
                            }, 1000);
                        } else {
                            $scope.operation = {
                                "success": false,
                                "message": "关闭失败"
                            };
                        }
                    })
                    .error(function () {
                        $scope.operation = {
                            "success": false,
                            "message": "关闭操作失败"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    });
            }
            
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })
;
