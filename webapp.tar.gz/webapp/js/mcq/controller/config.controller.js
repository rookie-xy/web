/**
 * config管理Controller
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqControllers')
    // 查询
    .controller('configQueryCtrl', function ($scope, configService) {
        /**
         * 搜索config
         * @param pageNo 页码，可选参数，不设置时将从当前作用域中获取页码信息
         * @param query 查询条件，可选参数，不设置时将查询所有config
         */
        $scope.search = function (pageNo, query) {
            $scope.loading = true;

            var pagination = {
                'pageNo': pageNo ? pageNo : $scope.paginationConf.pageNo,
                'pageSize': $scope.paginationConf.pageSize
            };
            var aQuery = query ? query : $scope.query;

            configService.search(aQuery, pagination).success(function (data) {
                if (data.status == 200) {
                    if (pageNo) {
                        $scope.paginationConf.pageNo = pageNo;
                    }
                    $scope.paginationConf.totalRecord = data.pagination.totalRecord;
                    $scope.configs = data.result;
                    $scope.loading = false;
                }
            });
        };

        // 初始化查询条件
        $scope.query = {};
        // 初始化分配设置
        $scope.paginationConf = {
            onChange: function () {
                $scope.search();
            }
        };

        $scope.search(1);
    }
)

    // 加载添加页面
    .controller('configAddModalCtrl', function ($scope, $uibModal) {

        $scope.modalTitle = '新增';

        $scope.toAddModal = function () {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/config/detail.tpl.html',
                controller: 'configAddCtrl',
                scope: $scope
            });
        };
    })

    // 添加
    .controller('configAddCtrl', function ($scope, $timeout, $uibModalInstance, configService) {

        /**
         * 新增config
         * @param config
         */
        $scope.ok = function (config) {
            $scope.confirmDisabled = true;

            configService.add(config)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            success: true,
                            message: '新增成功'
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            success: false,
                            message: data.message
                        };
                    }
                })
                .error(function () {
                    $scope.operation = {
                        success: false,
                        message: '新增失败'
                    };
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    })

    // 加载编辑页面
    .controller('configEditModalCtrl', function ($scope, $uibModal) {

        $scope.modalTitle = '编辑';

        $scope.toEditModal = function (configId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/config/detail.tpl.html',
                controller: 'configEditCtrl',
                scope: $scope,
                resolve: {
                    configId: configId
                }
            });
        };
    })

    // 编辑
    .controller('configEditCtrl', function ($scope, $timeout, $uibModalInstance, configService, configId) {

        /**
         * 编辑
         * @param config
         */
        $scope.ok = function (config) {
            $scope.confirmDisabled = true;
            configService.update(config)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "编辑成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": '编辑失败'
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        configService.findById(configId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.config = data.result;

                    $scope.operation = null;
                } else {
                    $scope.operation = {
                        success: false,
                        message: '数据加载失败'
                    };
                }
            })
            .error(function () {
                $scope.operation = {
                    success: false,
                    message: '数据加载失败'
                };
            });

    })

    // 加载删除页面
    .controller('configDeleteModalCtrl', function ($scope, $uibModal) {
        $scope.toDeleteModal = function (configId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/config/delete.tpl.html',
                controller: 'configDeleteCtrl',
                scope: $scope,
                resolve: {
                    configId: configId
                }
            });
        };
    })

    // 删除
    .controller('configDeleteCtrl', function ($scope, $timeout, $uibModalInstance, configService, configId) {
        /**
         * 删除
         * @param id config标识
         */
        $scope.ok = function () {
            $scope.confirmDisabled = true;
            configService.delete(configId)
                .success(function (data) {
                    if (data.status == 200) {
                        $scope.operation = {
                            "success": true,
                            "message": "删除成功"
                        };
                        $timeout(function () {
                            $scope.cancel();
                            $scope.search();
                        }, 1000);
                    } else {
                        $scope.operation = {
                            "success": false,
                            "message": data.message
                        }
                    }
                })
                .error(function () {
                    $scope.operation = {
                        "success": false,
                        "message": "删除失败"
                    }
                });
        };

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    });
