/**
 * 日期控件
 */
angular.module('mcqControllers')

    .controller('datepickerModalCtrl', function ($scope) {

        $scope.dateOptions = {
            maxDate: new Date(2020, 5, 22),
            minDate: new Date(),
            startingDay: 1
        };

        $scope.openDatepicker = function () {
            $scope.datepickerModal.opened = true;
        };

        $scope.datepickerModal = {
            opened: false
        };
    });