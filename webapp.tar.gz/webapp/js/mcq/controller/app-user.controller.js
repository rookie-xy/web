/**
 * 应用联系人模块
 *
 * @author zhuchunlai
 */
angular.module('mcqControllers')

    // 加载应用联系人Modal
    .controller('appUserModalCtrl', function ($scope, $uibModal) {
        /**
         * 加载应用联系人页面
         * @param appId 应用标识
         */
        $scope.toListModal = function (appId) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/app_user/list.tpl.html',
                controller: 'appUserQueryCtrl',
                resolve: {
                    appId: appId
                }
            });

        };
    })

    // 查询指定应用的联系人
    .controller('appUserQueryCtrl', function ($scope, $uibModalInstance, appUserService, appId) {

        /**
         * 关闭
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        // 查询应用联系人
        $scope.loading = true;

        appUserService.findByApp(appId)
            .success(function (data) {
                if (data.status == 200) {
                    $scope.appUsers = data.result;

                    $scope.loading = false;

                } else {
                    $scope.error = data.message;
                }
            })
            .error(function () {
                $scope.error = '数据加载失败！';
            });

    });