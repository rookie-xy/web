/**
 * 消费进度的Controller
 * @type {angular.Module}
 * @author zhangxiaodong01
 */
angular.module('mcqControllers')

    .controller('consumeOffsetCtrl', function ($scope, $uibModal) {
        $scope.toListModal = function (appCode, topicCode) {
            $uibModal.open({
                backdrop: false,
                keyboard: false,
                templateUrl: 'views/consume_offset/list.tpl.html',
                controller: 'consumeProgressModalCtrl',
                size: 'lg8',
                resolve: {
                    appTopic: function () {
                        return {
                            appCode: appCode,
                            topicCode: topicCode
                        };
                    }
                }
            });

        };

    })

    .controller('consumeProgressModalCtrl', function ($scope, $uibModalInstance, $timeout, $filter, consumeOffsetService, appTopic){
        $scope.aQuery = {};
        $scope.loading = false;
        $scope.aQuery.timeStamp = new Date();
        // 取消
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        /**
         * 设置消费进度
         */
        $scope.setConsumeOffset = function () {
            $scope.loading = true;
            var query = new Object();
            query.timeStamp = $filter('date')($scope.aQuery.timeStamp, 'yyyy-MM-dd HH:mm:ss');
            if (query.timeStamp == null || query.timeStamp == "undefined" || query.timeStamp == undefined) {
                $scope.rollbackStats = {};
                $scope.operation = {
                    success: false,
                    message: "请正确填写日期!"
                };
                $timeout(function () {
                    $scope.operation = null;
                }, 1000);
                return;
            }

            query.topicCode = appTopic.topicCode;
            query.appCode = appTopic.appCode;
            query.force = true;
            
            consumeOffsetService.setConsumeOffset(query).success(function (data) {
                if (data != null && data.status == 200) {
                    $scope.rollbackStats = data.result;
                    $scope.loading = false;
                } else if (data != null && (data.status == 500 || data.status == 300)) {
                    $scope.rollbackStats = {};
                    $scope.operation = {
                        success: false,
                        message: data.message
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);
                } else {
                    $scope.rollbackStats = {};
                    $scope.operation = {
                        success: false,
                        message: "服务端返回数据不正确"
                    };
                    $timeout(function () {
                        $scope.operation = null;
                    }, 1000);
                }

            });
        }

    });


