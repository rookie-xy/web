'use strict';

// 定义应用模块
var mcqControllers = angular.module('mcqControllers', ['ngAnimate', 'ui.bootstrap', 'checklist-model', 'tm.pagination', 'ui.bootstrap.datetimepicker', 'ng-echarts']);
var mcqServices = angular.module('mcqServices', []);

// 定义应用
var app = angular.module("mcq", ['ngRoute', 'mcqControllers', 'mcqServices']);

// 定义路由
app.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when("/config", {controller: 'configQueryCtrl', templateUrl: 'views/config/list.tpl.html'})
        .when("/user", {controller: 'userQueryCtrl', templateUrl: 'views/user/list.tpl.html'})
        .when("/app", {controller: 'appQueryCtrl', templateUrl: 'views/app/list.tpl.html'})
        .when("/topic", {controller: 'topicQueryCtrl', templateUrl: 'views/topic/list.tpl.html'})
        .when("/app_topic", {controller: 'gatewayQueryCtrl', templateUrl: 'views/gateway/list.tpl.html'})
        .when("/my_apply", {controller: 'applyQueryCtrl', templateUrl: 'views/apply/list.tpl.html'})
        .when("/apply", {controller: 'applyAddCtrl', templateUrl: 'views/apply/add.tpl.html'})
        .when("/broker", {controller: 'brokerQueryCtrl', templateUrl: 'views/broker/list.tpl.html'})
        .when("/dashboard", {controller: 'dashboardQueryCtrl', templateUrl: 'views/dashboard/dashboard.tpl.html'})
        .when("/monitor/broker", {
            controller: 'brokerMonitorQueryCtrl',
            templateUrl: 'views/monitor/broker/list.tpl.html'
        })
        .when("/monitor/consume", {
            controller: 'consumeMonitorQueryCtrl',
            templateUrl: 'views/monitor/consume/list.tpl.html'
        })
        .when("/monitor/produce", {
            controller: 'produceMonitorQueryCtrl',
            templateUrl: 'views/monitor/produce/list.tpl.html'
        })
        .when("/task", {controller: 'taskQueryCtrl', templateUrl: 'views/task/list.tpl.html'})
        .when("/executor", {controller: 'executorQueryCtrl', templateUrl: 'views/executor/list.tpl.html'})
        .when("/alarm_type", {controller: 'alarmTypeQueryCtrl', templateUrl: 'views/alarm_type/list.tpl.html'})
        .when("/alarm_policy", {controller: 'alarmPolicyQueryCtrl', templateUrl: 'views/alarm_policy/list.tpl.html'})
        .when("/alarm_event", {controller: 'alarmEventQueryCtrl', templateUrl: 'views/alarm_event/list.tpl.html'})
        .when("/gw_log", {controller: 'gatewayLogQueryCtrl', templateUrl: 'views/gateway_log/list.tpl.html'})
        .when("/jmx", {controller: 'messageConsumerQueryCtrl', templateUrl: 'views/jmx/list.tpl.html'})
        .otherwise({redirectTo: '/dashboard'});

}]);

// 定义页面标题常量
app.constant('CONSTANT_PAGE_HEADER', {
    '/config': {'title': '配置管理', 'breadcrumbs': ['系统管理', '配置管理']},
    '/user': {'title': '用户管理', 'breadcrumbs': ['系统管理', '用户管理']},
    '/app': {'title': '应用管理', 'breadcrumbs': ['系统管理', '应用管理']},
    '/task': {'title': '任务管理', 'breadcrumbs': ['系统管理', '任务管理']},
    '/executor': {'title': '执行器', 'breadcrumbs': ['系统管理', '执行器']},
    '/broker': {'title': 'Broker管理', 'breadcrumbs': ['消息管理', 'Broker管理']},
    '/topic': {'title': '主题管理', 'breadcrumbs': ['消息管理', '主题管理']},
    '/app_topic': {'title': '订阅关系', 'breadcrumbs': ['消息管理', '订阅关系']},
    '/my_apply': {'title': '我的申请', 'breadcrumbs': ['消息管理', '消息接入', '我的申请']},
    '/apply': {'title': '申请接入', 'breadcrumbs': ['消息管理', '消息接入', '申请接入']},
    '/dashboard': {'title': 'Dashboard', 'breadcrumbs': []},
    '/monitor/broker': {'title': 'Broker监控', 'breadcrumbs': ['监控报警', 'Broker监控']},
    '/monitor/consume': {'title': '消费监控', 'breadcrumbs': ['监控报警', '消费监控']},
    '/monitor/produce': {'title': '生产监控', 'breadcrumbs': ['监控报警', '生产监控']},
    '/alarm_type': {'title': '采集指标', 'breadcrumbs': ['监控报警', '采集指标']},
    '/alarm_policy': {'title': '报警策略', 'breadcrumbs': ['监控报警', '报警策略']},
    '/alarm_event': {'title': '报警记录', 'breadcrumbs': ['监控报警', '报警记录']},
    '/gw_log': {'title': '网关日志', 'breadcrumbs': ['监控报警', '网关日志']},
    '/jmx': {'title': '消费网关订阅关系', 'breadcrumbs': ['监控报警', '消费网关订阅关系']}
});

// 定义帮助类常量
app.constant('USER_GUIDE', 'https://wiki.sprucetec.com/pages/viewpage.action?pageId=3426525');

// 全局方法，设置当前用户、判断是否认证以及设置页面标题和面包屑
app.run(function ($rootScope, $location, $uibModal, $timeout, CONSTANT_PAGE_HEADER, userService, configService) {

    // 设置当前登录用户
    userService.getCurrent().success(function (data) {
        $rootScope.currentUser = data.result;
    });

    // 设置权限处理的方法
    $rootScope.isAuthorized = function (expectedRoles) {
        var user = $rootScope.currentUser;

        return userService.isAuthorized(user, expectedRoles);
    };

    // 判断当前用户是否认证通过
    $rootScope.isAuthenticated = function () {
        var user = $rootScope.currentUser;

        return user != null || user != undefined;
    };

    // 获取客户端版本
    var defaultClientVersion = '0.2.0';
    // 获取客户端版本
    configService.findByKey('client', 'version')
        .success(function (response) {
            if (response.status == 200) {
                var version = response.result;
                if (version) {
                    if (version.value) {
                        $rootScope.mcqClientVersion = version.value;
                    } else {
                        $rootScope.mcqClientVersion = defaultClientVersion;
                    }
                } else {
                    $rootScope.mcqClientVersion = defaultClientVersion;
                }
            } else {
                $rootScope.mcqClientVersion = defaultClientVersion;
            }
        })
        .error(function () {
            $rootScope.mcqClientVersion = defaultClientVersion;
        });

    /**
     * 加载个人信息页面
     */
    $rootScope.toProfileModal = function () {
        $uibModal.open({
            backdrop: false,
            keyboard: false,
            templateUrl: 'views/user/edit.tpl.html',
            controller: 'userEditCtrl',
            resolve: {
                userId: $rootScope.currentUser.id,
                profileModal: true
            }
        });
    };

    // 监听路径变化事件，修改页面标题和面包屑
    $rootScope.$on('$locationChangeSuccess', function () {
        var header = CONSTANT_PAGE_HEADER[$location.path()];
        if (header != undefined) {
            $rootScope.pageHeader = header.title;
            $rootScope.breadcrumbs = header.breadcrumbs;
        }
    });
});