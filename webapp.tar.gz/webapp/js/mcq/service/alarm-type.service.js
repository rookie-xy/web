angular.module('mcqServices')
    .service('alarmTypeService', function ($http) {

        var alarmTypeService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        alarmTypeService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'alarm_type/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };


        /**
         * 添加
         * @param alarmType 报警类型
         * @returns {*}
         */
        alarmTypeService.add = function (alarmType) {
            return $http({
                method: 'POST',
                url: 'alarm_type.do',
                data: $.param(alarmType),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 查询指定报警类型的信息
         * @param id ID标识
         * @returns {HttpPromise}
         */
        alarmTypeService.findById = function (id) {
            return $http.get("alarm_type/" + id + ".do");
        };

        /**
         * 编辑
         * @param alarmType 报警类型
         * @returns {HttpPromise}
         */
        alarmTypeService.update = function (alarmType) {
            return $http({
                method: 'PUT',
                url: 'alarm_type.do',
                data: $.param(alarmType),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 删除
         * @param id ID标识
         * @returns {HttpPromise}
         */
        alarmTypeService.delete = function (id) {
            return $http.delete('alarm_type/' + id + '.do');
        };

        /**
         * 禁用
         * @param id ID标识
         * @returns {HttpPromise} HTTP响应
         */
        alarmTypeService.disable = function (id) {
            return $http.post('alarm_type/disable/' + id + '.do', []);
        };

        /**
         * 启用
         * @param id ID标识
         * @returns {HttpPromise}
         */
        alarmTypeService.enable = function (id) {
            return $http.post('alarm_type/enable/' + id + '.do', []);
        };


        return alarmTypeService;

    });