angular.module('mcqServices')
    .service('alarmPolicyService', function ($http) {

        var alarmPolicyService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        alarmPolicyService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'alarm_policy/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };


        /**
         * 添加
         * @param alarmType 报警策略
         * @returns {*}
         */
        alarmPolicyService.add = function (alarmPolicy) {
            return $http({
                method: 'POST',
                url: 'alarm_policy.do',
                data: $.param(alarmPolicy),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 查询指定报警策略的信息
         * @param id ID标识
         * @returns {HttpPromise}
         */
        alarmPolicyService.findById = function (id) {
            return $http.get("alarm_policy/" + id + ".do");
        };

        /**
         * 编辑
         * @param alarmPolicy 报警策略
         * @returns {HttpPromise}
         */
        alarmPolicyService.update = function (alarmPolicy) {
            return $http({
                method: 'PUT',
                url: 'alarm_policy.do',
                data: $.param(alarmPolicy),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 删除
         * @param id ID标识
         * @returns {HttpPromise}
         */
        alarmPolicyService.delete = function (id) {
            return $http.delete('alarm_policy/' + id + '.do');
        };

        /**
         * 禁用
         * @param id ID标识
         * @returns {HttpPromise} HTTP响应
         */
        alarmPolicyService.disable = function (id) {
            return $http.post('alarm_policy/disable/' + id + '.do', []);
        };

        /**
         * 启用
         * @param id ID标识
         * @returns {HttpPromise}
         */
        alarmPolicyService.enable = function (id) {
            return $http.post('alarm_policy/enable/' + id + '.do', []);
        };

        return alarmPolicyService;

    });