angular.module('mcqServices')
    .service('consumeOffsetService', function ($http) {
        var consumeOffsetService = {};

        /**
         * 设置消费进度
         * @param query 参数:topicCode,appCode,timeStamp,force
         * @returns {*}
         */
        consumeOffsetService.setConsumeOffset = function (data) {
            
            return $http({
                method: 'POST',
                url: 'consume_offset/set.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };
        
        return consumeOffsetService;
    });