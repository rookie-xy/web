/**
 * 申请服务
 */
angular.module("mcqServices")
    .service("applyService", function ($http) {
        var applyService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        applyService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'apply/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };


        /**
         * 添加申请
         * @param apply 申请
         * @returns {*}
         */
        applyService.add = function (apply) {
            return $http({
                method: 'POST',
                url: 'apply.do',
                data: $.param(apply),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };


        return applyService;
    });