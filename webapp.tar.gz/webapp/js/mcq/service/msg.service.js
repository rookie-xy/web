angular.module('mcqServices')
    .service('msgService', function ($http) {
        var msgService = {};

        /**
         * 搜索
         * @param query 查询条件:topicCode,msgKey 
         * @returns {*}
         */
        msgService.searchByKey = function (data) {

            return $http({
                method: 'POST',
                url: 'msg/key/show.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };
        
        msgService.searchById = function (data) {
          
            return $http({
                method: 'POST', 
                url: 'msg/id/show.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };
        
        msgService.searchByOffset = function (data) {
          
            return $http({
                method: 'POST',
                url: 'msg/offset/show.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        return msgService;
    });