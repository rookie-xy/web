/**
 * broker模块的业务逻辑
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqServices')
    .service('brokerService', function ($http) {
        var brokerService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        brokerService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'brokerAction/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 按照ID查询broker明细
         * @param id broker ID
         * @returns {HttpPromise}
         */
        brokerService.findById = function (id) {
            return $http.get('brokerAction/' + id + '.do', []);
        };

        /**
         * 新增broker
         * @param broker
         * @returns {*}
         */
        brokerService.add = function (broker) {
            return $http({
                method: 'POST',
                url: 'brokerAction.do',
                data: $.param(broker),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 编辑broker信息
         * @param broker 用户信息
         * @returns {*}
         */
        brokerService.update = function (broker) {
            return $http({
                method: 'PUT',
                url: 'brokerAction.do',
                data: $.param(broker),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 删除
         * @param id broker标识
         * @returns {HttpPromise}
         */
        brokerService.delete = function (id) {
            return $http.delete('brokerAction/' + id + '.do');
        };

        /**
         * 查询指定Topic分配的Broker列表
         * @param topicId topic标识
         */
        brokerService.findByTopic = function (topicId) {
            return $http.get('brokerAction/search/' + topicId + '.do');
        };

        /**
         * 获取所有有效的Broker列表
         * @returns {HttpPromise}
         */
        brokerService.findAll = function () {
            return $http.post('brokerAction/search/all.do')
        };


        return brokerService;
    });