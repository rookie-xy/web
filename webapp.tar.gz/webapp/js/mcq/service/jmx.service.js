angular.module('mcqServices')
    .service('jmxService', function ($http) {
        var jmxService = {};

        jmxService.search = function (gatewayHost) {

            return $http({
                method: 'GET',
                url: 'jmx/search/' + gatewayHost + '.do',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };
        
        return jmxService;
    })
;