/**
 * 主题模块的业务逻辑
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqServices')
    .service('topicService', function ($http) {
        var topicService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        topicService.search = function (query, pagination) {
            return search0(query, pagination, 'topicAction/search.do');
        };

        /**
         * 根据主题明细
         * @param id 主题ID
         * @returns {HttpPromise}
         */
        topicService.findById = function (id) {
            return $http.get("topicAction/" + id + ".do");
        };


        /**
         * 编辑主题
         * @param topic 主题
         * @returns {HttpPromise}
         */
        topicService.update = function (topic) {
            return $http({
                method: "PUT",
                url: "topicAction.do",
                data: $.param(topic),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 采用数据字典的方式搜索Topic信息
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        topicService.searchDictionary = function (query, pagination) {
            return search0(query, pagination, 'topicAction/dictionary.do');
        };

        /**
         * 删除主题
         * @param id 主题标识
         * @returns {HttpPromise}
         */
        topicService.delete = function (id) {
            return $http.delete('topicAction/' + id + '.do');
        };

        /**
         * 分配Broker
         * @param topicId topic标识
         * @param brokers broker列表
         * @returns {*}
         */
        topicService.allocateBroker = function (topicId, brokers) {
            return $http.post('topicAction/allocate_broker/' + topicId + '.do', brokers);
        };

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @param url 请求地址
         * @returns {*}
         */
        function search0(query, pagination, url) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }
            return $http({
                method: 'POST',
                url: url,
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        }


        return topicService;
    });