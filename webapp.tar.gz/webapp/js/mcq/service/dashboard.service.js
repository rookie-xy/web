/**
 * 统计主页数据
 * @type {angular.Module}
 * @author zhangxiaodong01
 */
angular.module('mcqServices')
    .service('dashboardService', function ($http) {
        var dashboardService = {};
        
        dashboardService.queryMessageCountMetrics = function(role) {
            var topicCode = "DefaultCluster@customer";
            if (role == "produce") {
                topicCode = "DefaultCluster@producer";
            }
            
            return $http({
                method: 'POST',
                url: 'monitor/produce/stats.do',
                data: $.param({
                    topicCode: topicCode
                }),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };
        return dashboardService;
    });