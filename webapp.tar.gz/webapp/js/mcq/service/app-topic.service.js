/**
 * 订阅关系服务
 */
angular.module("mcqServices")
    .service("appTopicService", function ($http) {
        var appTopicService = {};
        
        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        appTopicService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'app_topic/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 查询指定Topic的订阅关系
         * @param topicId topic标识
         * @returns {HttpPromise}
         */
        appTopicService.findByTopic = function (topicId) {
            return $http.get('app_topic/search/' + topicId + '.do');
        };

        /**
         * 批量删除指定app/Topic的订阅关系
         * @param appTopicIdList
         * @returns {HttpPromise}
         */
        appTopicService.batchDelete = function (appTopicIdList){
            return $http.post('app_topic/batch_delete.do', appTopicIdList);
        };

        /**
         * 开启消费网关消费者
         * @param appTopicId
         */
        appTopicService.enable = function (appTopic) {
            return $http.post('app_topic/enable.do', appTopic);
            
        };

        /**
         * 关闭消费网关消费者
         * @param appTopicId
         */
        appTopicService.disable = function (appTopic) {
            return $http.post('app_topic/disable.do', appTopic);
        };
        
        return appTopicService;
    });