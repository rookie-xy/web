angular.module('mcqServices')
    .service('produceMonitorService', function ($http) {

        var produceMonitorService = {};

        produceMonitorService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'monitor/produce/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        produceMonitorService.queryProduceMetrics = function(topicCode) {
            
            return $http({
                method: 'POST',
                url: 'monitor/produce/stats.do',
                data: $.param({
                    topicCode: topicCode
                }),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };
        
        return produceMonitorService;

    });