/**
 * 应用模块的业务逻辑
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqServices')
    .service('appService', function ($http) {
        var appService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        appService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'app/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 查看应用明细
         * @param id 应用ID
         * @returns {HttpPromise}
         */
        appService.findById = function (id) {
            return $http.get("app/" + id + ".do");
        };

        /**
         * 编辑应用
         * @param app 应用
         * @returns {HttpPromise}
         */
        appService.update = function (app) {
            return $http({
                method: 'PUT',
                url: 'app.do',
                data: $.param(app),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 删除应用
         * @param id 应用标识
         * @returns {HttpPromise}
         */
        appService.delete = function (id){
            return $http.delete('app/' + id + '.do');
        };

        return appService;
    });