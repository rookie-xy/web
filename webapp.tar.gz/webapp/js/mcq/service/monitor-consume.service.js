angular.module('mcqServices')
    .service('consumeMonitorService', function ($http) {

        var consumeMonitorService = {};

        consumeMonitorService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'monitor/consume/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        consumeMonitorService.queryConsumeMetrics = function(appCode, topicCode) {
            return $http({
                method: 'POST',
                url: 'monitor/consume/stats.do',
                data: $.param({
                    appCode: appCode,
                    topicCode: topicCode
                }),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        return consumeMonitorService;

    });