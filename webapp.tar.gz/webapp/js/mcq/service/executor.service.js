/**
 * 执行器模块的业务逻辑
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqServices')
    .service('executorService', function ($http) {
        var executorService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        executorService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'executor/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 查看执行器明细
         * @param id 任务ID
         * @returns {HttpPromise}
         */
        executorService.findById = function (id) {
            return $http.get("executor/" + id + ".do");
        };

        /**
         * 新增任务信息
         * @param executor 执行器
         * @returns {*}
         */
        executorService.add = function (executor) {
            return $http({
                method: 'POST',
                url: 'executor.do',
                data: $.param(executor),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 编辑执行器
         * @param executor 执行器
         * @returns {HttpPromise}
         */
        executorService.update = function (executor) {
            return $http({
                method: 'PUT',
                url: 'executor.do',
                data: $.param(executor),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 删除执行器
         * @param id 应用标识
         * @returns {HttpPromise}
         */
        executorService.delete = function (id) {
            return $http.delete('executor/' + id + '.do');
        };

        return executorService;
    });