/**
 * 配置服务
 */
angular.module("mcqServices")
    .service("configService", function ($http) {

        var configService = {};

        /**
         * 依据分组和key查询配置信息
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        configService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }
            return $http({
                method: 'POST',
                url: 'config/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 根据ID查询配置信息明细
         * @param id 配置信息标识
         * @returns {HttpPromise}
         */
        configService.findById = function (id) {
            return $http.get('config/' + id + '.do', []);
        };

        /**
         * 添加指定配置信息
         * @param config 配置信息
         * @returns {*}
         */
        configService.add = function (config) {
            return $http({
                method: 'POST',
                url: 'config.do',
                data: $.param(config),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 编辑config信息
         * @param config 配置信息
         * @returns {*}
         */
        configService.update = function (config) {
            return $http({
                method: 'PUT',
                url: 'config.do',
                data: $.param(config),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 删除
         * @param id broker标识
         * @returns {HttpPromise}
         */
        configService.delete = function (id) {
            return $http.delete('config/' + id + '.do');
        };

        /**
         * 查找指定key的配置信息
         * @param group 分组
         * @param key 配置名
         */
        configService.findByKey = function (group, key) {
            var config = {
                'group': group,
                'key': key
            };

            return $http({
                method: 'POST',
                url: 'config/search/key.do',
                data: $.param(config),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        return configService;
    });