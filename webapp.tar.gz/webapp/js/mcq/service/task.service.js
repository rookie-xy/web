/**
 * 任务模块的业务逻辑
 * @type {angular.Module}
 * @author zhufei
 */
angular.module('mcqServices')
    .service('taskService', function ($http) {
        var taskService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        taskService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'task/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 查看任务明细
         * @param id 任务ID
         * @returns {HttpPromise}
         */
        taskService.findById = function (id) {
            return $http.get("task/" + id + ".do");
        };

        /**
         * 新增任务信息
         * @param task 任务
         * @returns {*}
         */
        taskService.add = function(task){
            return $http({
                method: 'POST',
                url: 'task.do',
                data: $.param(task),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 编辑任务
         * @param app 任务
         * @returns {HttpPromise}
         */
        taskService.update = function (task) {
            return $http({
                method: 'PUT',
                url: 'task.do',
                data: $.param(task),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 删除应用
         * @param id 应用标识
         * @returns {HttpPromise}
         */
        taskService.delete = function (id){
            return $http.delete('task/' + id + '.do');
        };

        return taskService;
    });