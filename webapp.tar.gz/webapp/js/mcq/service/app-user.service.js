/**
 * 应用联系人模块的业务逻辑
 * @type {angular.Module}
 */
angular.module('mcqServices')
    .service("appUserService", function ($http) {

        var appUserService = {};

        /**
         * 获取应用的联系人信息
         * @param appId 应用ID
         * @returns {HttpPromise}
         */
        appUserService.findByApp = function (appId) {
            return $http.get(
                '/app_user/search/' + appId + '.do'
            );
        };

        return appUserService;

    });