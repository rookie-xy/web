/**
 * 用户模块的业务逻辑
 * @type {angular.Module}
 * @author zhuchunlai
 */
angular.module('mcqServices')
    .service('userService', function ($http, $filter) {
        var userService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        userService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'user/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 按照ID查询用户明细
         * @param id 用户ID
         * @returns {HttpPromise}
         */
        userService.findById = function (id) {
            return $http.get('user/' + id + '.do', []);
        };

        /**
         * 编辑用户信息
         * @param user 用户信息
         * @returns {*}
         */
        userService.update = function (user) {
            var aUser = angular.copy(user);

            if (aUser.createTime) {
                aUser.createTime = $filter('date')(aUser.createTime, 'yyyy-MM-dd HH:mm:ss');
            }
            if (aUser.updateTime) {
                aUser.updateTime = $filter('date')(aUser.updateTime, 'yyyy-MM-dd HH:mm:ss');
            }
            
            return $http({
                method: 'PUT',
                url: 'user.do',
                data: $.param(aUser),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        /**
         * 禁用
         * @param id 用户ID
         * @returns {HttpPromise} HTTP响应
         */
        userService.disable = function (id) {
            return $http.post('user/disable/' + id + '.do', []);
        };

        /**
         * 启用
         * @param id 用户ID
         * @returns {HttpPromise}
         */
        userService.enable = function (id) {
            return $http.post('user/enable/' + id + '.do', []);
        };

        /**
         * 当前用户
         * @returns {HttpPromise}
         */
        userService.getCurrent = function () {
            return $http.post("user/current.do", []);
        };

        /**
         * 验证用户权限是否符合期望
         * @param user 用户
         * @param expectedRoles 期望权限
         * @returns {boolean} true，满足权限要求；反之则不满去
         */
        userService.isAuthorized = function (user, expectedRoles) {
            if (!angular.isArray(expectedRoles)) {
                expectedRoles = [expectedRoles];
            }

            if (user && user.role) {
                return expectedRoles.indexOf(user.role) != -1;
            }
            return false;
        };

        return userService;
    });