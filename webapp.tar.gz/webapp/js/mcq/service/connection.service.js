angular.module('mcqServices')
    .service('connectionService', function ($http) {

        var connectionService = {};

        connectionService.findConsumer = function (appCode, topicCode) {
            return $http({
                method: 'POST',
                url: 'monitor/connection/consumer.do',
                data: $.param({
                    appCode: appCode,
                    topicCode: topicCode
                }),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });

        };

        connectionService.findProducer = function (appCode, topicCode) {
            return $http({
                method: 'POST',
                url: 'monitor/connection/producer.do',
                data: $.param({
                    appCode: appCode,
                    topicCode: topicCode
                }),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };

        return connectionService;

    });