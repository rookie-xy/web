angular.module('mcqServices')
    .service('gatewayLogService', function ($http) {
        var gatewayLogService = {};

        /**
         * 搜索
         * @param query 查询条件
         * @param pagination 分页
         * @returns {*}
         */
        gatewayLogService.search = function (query, pagination) {
            var data = angular.copy(query);
            if (pagination.pageNo) {
                data['pageNo'] = pagination.pageNo;
            }
            if (pagination.pageSize) {
                data['pageSize'] = pagination.pageSize;
            }

            return $http({
                method: 'POST',
                url: 'gw_log/search.do',
                data: $.param(data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            });
        };


        return gatewayLogService;
    });